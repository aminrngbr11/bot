<?php

$ApiToken = "BotTokenNew";